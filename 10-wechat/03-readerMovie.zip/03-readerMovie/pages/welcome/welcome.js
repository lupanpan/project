Page({
  onTap: function (event){
    wx.redirectTo({
      url: '../posts/posts',
    })
  }
})